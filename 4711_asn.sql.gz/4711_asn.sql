-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 12, 2015 at 11:59 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `4711_asn`
--

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

DROP TABLE IF EXISTS `ci_sessions`;
CREATE TABLE IF NOT EXISTS `ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `roster`
--

DROP TABLE IF EXISTS `roster`;
CREATE TABLE IF NOT EXISTS `roster` (
  `Id` int(11) NOT NULL,
  `Name` varchar(22) NOT NULL,
  `Pos` varchar(4) NOT NULL,
  `Status` varchar(4) NOT NULL,
  `Height` varchar(6) NOT NULL,
  `Weight` int(11) NOT NULL,
  `Birthdate` date NOT NULL,
  `Exp` int(11) NOT NULL,
  `College` varchar(24) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roster`
--

INSERT INTO `roster` (`Id`, `Name`, `Pos`, `Status`, `Height`, `Weight`, `Birthdate`, `Exp`, `College`) VALUES
(5, 'Forbath, Kai', 'K', 'ACT', '5''11"', 197, '0000-00-00', 4, 'UCLA'),
(6, 'Morstead, Thomas', 'P', 'ACT', '6''4"', 235, '0000-00-00', 7, 'Southern Methodist'),
(9, 'Brees, Drew', 'QB', 'ACT', '6''0"', 209, '0000-00-00', 15, 'Purdue'),
(10, 'Cooks, Brandin', 'WR', 'ACT', '5''10"', 189, '0000-00-00', 2, 'Oregon State'),
(12, 'Colston, Marques', 'WR', 'ACT', '6''4"', 225, '0000-00-00', 10, 'Hofstra'),
(16, 'Coleman, Brandon', 'WR', 'ACT', '6''6"', 225, '0000-00-00', 1, 'Rutgers'),
(17, 'Graham, T.J.', 'WR', 'ACT', '5''11"', 188, '0000-00-00', 4, 'North Carolina State'),
(18, 'Grayson, Garrett', 'QB', 'ACT', '6''2"', 220, '0000-00-00', 0, 'Colorado State'),
(20, 'Dixon, Brian', 'DB', 'ACT', '6''0"', 195, '0000-00-00', 2, 'Northwest Missouri State'),
(21, 'Lewis, Keenan', 'CB', 'ACT', '6''1"', 208, '0000-00-00', 7, 'Oregon State'),
(22, 'Ingram, Mark', 'RB', 'ACT', '5''9"', 215, '0000-00-00', 5, 'Alabama'),
(24, 'Wilson, Kyle', 'DB', 'ACT', '5''10"', 190, '0000-00-00', 6, 'Boise State'),
(25, 'Bush, Rafael', 'FS', 'RES', '5''11"', 205, '0000-00-00', 5, 'South Carolina State'),
(27, 'Swann, Damian', 'CB', 'ACT', '6''0"', 189, '0000-00-00', 0, 'Georgia'),
(28, 'Spiller, C.J.', 'RB', 'ACT', '5''11"', 200, '0000-00-00', 6, 'Clemson'),
(29, 'Robinson, Khiry', 'RB', 'RES', '6''0"', 220, '0000-00-00', 3, 'West Texas A&M'),
(31, 'Byrd, Jairus', 'FS', 'ACT', '5''10"', 203, '0000-00-00', 7, 'Oregon'),
(32, 'Vaccaro, Kenny', 'SS', 'ACT', '6''0"', 214, '0000-00-00', 3, 'Texas'),
(33, 'Sanford, Jamarca', 'SS', 'ACT', '5''10"', 200, '0000-00-00', 7, 'Mississippi'),
(34, 'Hightower, Tim', 'RB', 'ACT', '6''0"', 220, '0000-00-00', 4, 'Richmond'),
(36, 'Williams, P.J.', 'CB', 'RES', '6''0"', 196, '0000-00-00', 0, 'Florida State'),
(39, 'Browner, Brandon', 'CB', 'ACT', '6''4"', 221, '0000-00-00', 6, 'Oregon State'),
(40, 'Breaux, Delvin', 'CB', 'ACT', '6''1"', 196, '0000-00-00', 1, 'LSU'),
(43, 'Sunseri, Vinnie', 'SAF', 'RES', '6''0"', 210, '0000-00-00', 2, 'Alabama'),
(44, 'Kikaha, Hau''oli', 'OLB', 'ACT', '6''3"', 246, '0000-00-00', 0, 'Washington'),
(47, 'Drescher, Justin', 'LS', 'ACT', '6''1"', 235, '0000-00-00', 6, 'Colorado'),
(48, 'Murphy, Marcus', 'RB', 'ACT', '5''9"', 195, '0000-00-00', 0, 'Missouri State'),
(50, 'Anthony, Stephone', 'MLB', 'ACT', '6''2"', 245, '0000-00-00', 0, 'Clemson'),
(53, 'Humber, Ramon', 'OLB', 'ACT', '5''11"', 232, '0000-00-00', 7, 'North Dakota State'),
(54, 'Dunbar, Jo-Lonn', 'LB', 'ACT', '6''0"', 235, '0000-00-00', 8, 'Boston College'),
(55, 'Tull, Davis', 'OLB', 'RES', '6''3"', 240, '0000-00-00', 0, 'Tennessee-Chattanooga'),
(56, 'Mauti, Michael', 'LB', 'ACT', '6''2"', 243, '0000-00-00', 3, 'Penn State'),
(57, 'Hawthorne, David', 'OLB', 'ACT', '6''0"', 246, '0000-00-00', 8, 'Texas Christian'),
(58, 'Gwacham, Obum', 'DE', 'ACT', '6''5"', 246, '0000-00-00', 0, 'Oregon State'),
(59, 'Ellerbe, Dannell', 'OLB', 'ACT', '6''1"', 245, '0000-00-00', 7, 'Georgia'),
(60, 'Unger, Max', 'C', 'ACT', '6''5"', 305, '0000-00-00', 7, 'Oregon'),
(64, 'Strief, Zach', 'T', 'ACT', '6''7"', 320, '0000-00-00', 10, 'Northwestern'),
(65, 'Kelemete, Senio', 'G', 'ACT', '6''3"', 300, '0000-00-00', 3, 'Washington'),
(68, 'Lelito, Tim', 'OG', 'ACT', '6''4"', 315, '0000-00-00', 3, 'Grand Valley State'),
(71, 'Brown, Austin', 'NT', 'RES', '6''2"', 295, '0000-00-00', 0, 'Miami (Ohio)'),
(72, 'Armstead, Terron', 'T', 'ACT', '6''5"', 304, '0000-00-00', 3, 'Arkansas-Pine Bluff'),
(73, 'Evans, Jahri', 'G', 'ACT', '6''4"', 318, '0000-00-00', 10, 'Bloomsburg'),
(75, 'Peat, Andrus', 'OT', 'ACT', '6''7"', 316, '0000-00-00', 0, 'Stanford'),
(77, 'McGlynn, Mike', 'OT', 'ACT', '6''4"', 325, '0000-00-00', 7, 'Pittsburgh'),
(78, 'Richardson, Bobby', 'DE', 'ACT', '6''3"', 286, '0000-00-00', 0, 'Indiana'),
(82, 'McCown, Luke', 'QB', 'RES', '6''4"', 217, '0000-00-00', 12, 'Louisiana Tech'),
(83, 'Snead, Willie', 'WR', 'ACT', '5''11"', 195, '0000-00-00', 1, 'Ball State'),
(84, 'Hoomanawanui, Michael', 'TE', 'ACT', '6''4"', 265, '0000-00-00', 6, 'Illinois'),
(89, 'Hill, Josh', 'TE', 'ACT', '6''5"', 250, '0000-00-00', 3, 'Idaho State'),
(90, 'Barnes, Tavaris', 'DE', 'ACT', '6''3"', 275, '0000-00-00', 0, 'Clemson'),
(91, 'Edebali, Kasim', 'OLB', 'ACT', '6''2"', 253, '0000-00-00', 2, 'Boston College'),
(92, 'Jenkins, John', 'DT', 'ACT', '6''3"', 359, '0000-00-00', 3, 'Georgia'),
(93, 'Williams, Kevin', 'DT', 'ACT', '6''5"', 311, '0000-00-00', 13, 'Oklahoma State'),
(94, 'Jordan, Cameron', 'DE', 'ACT', '6''4"', 287, '0000-00-00', 5, 'California'),
(95, 'Davison, Tyeler', 'DT', 'ACT', '6''2"', 309, '0000-00-00', 0, 'Fresno State'),
(96, 'Virgil, Lawrence', 'DT', 'RES', '6''5"', 290, '0000-00-00', 1, 'Valdosta State'),
(98, 'Hills, Tony', 'OT', 'ACT', '6''5"', 304, '0000-00-00', 7, 'Texas'),
(100, 'Anderson, James', 'LB', 'ACT', '6''2"', 235, '0000-00-00', 10, 'Virginia Tech'),
(101, 'Flynn, Matt', 'QB', 'ACT', '6''2"', 225, '0000-00-00', 8, 'LSU'),
(102, 'Tabb, Jack', 'TE', 'RES', '6''3"', 250, '0000-00-00', 0, 'North Carolina'),
(104, 'Eulls, Kaleb', 'DT', 'ACT', '6''4"', 285, '0000-00-00', 0, 'Mississippi State'),
(105, 'Watson, Benjamin', 'TE', 'ACT', '6''3"', 255, '0000-00-00', 12, 'Georgia');

-- --------------------------------------------------------

--
-- Table structure for table `standing`
--

DROP TABLE IF EXISTS `standing`;
CREATE TABLE IF NOT EXISTS `standing` (
  `Id` int(11) NOT NULL,
  `Team` varchar(21) NOT NULL,
  `W` int(11) NOT NULL,
  `L` int(11) NOT NULL,
  `T` bit(1) NOT NULL,
  `Pct_1` decimal(5,3) NOT NULL,
  `PF` int(11) NOT NULL,
  `PA` date NOT NULL,
  `Net_Pts` int(11) NOT NULL,
  `TD` int(11) NOT NULL,
  `Home` varchar(6) NOT NULL,
  `Road` varchar(6) NOT NULL,
  `Division` varchar(6) NOT NULL,
  `Pct_2` decimal(5,3) NOT NULL,
  `Conf` varchar(6) NOT NULL,
  `NonConf` varchar(6) NOT NULL,
  `Streak` varchar(3) NOT NULL,
  `Last_5` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `standing`
--

INSERT INTO `standing` (`Id`, `Team`, `W`, `L`, `T`, `Pct_1`, `PF`, `PA`, `Net_Pts`, `TD`, `Home`, `Road`, `Division`, `Pct_2`, `Conf`, `NonConf`, `Streak`, `Last_5`) VALUES
(1, 'New England Patriots', 8, 0, b'0', '1.000', 276, '0000-00-00', 133, 31, 'May-00', 'Mar-00', 'Mar-00', '1.000', 'Jun-00', 'Feb-00', '8W', 'May-00'),
(2, 'New York Jets', 5, 3, b'0', '0.625', 200, '0000-00-00', 38, 23, '1-Mar', '2-Feb', '1-Jan', '0.500', '2-Apr', '1-Jan', '1W', '2-Mar'),
(3, 'Buffalo Bills', 4, 4, b'0', '0.500', 209, '0000-00-00', 19, 26, '3-Feb', '1-Feb', '1-Feb', '0.667', '3-Apr', '0-1', '1W', '3-Feb'),
(4, 'Miami Dolphins', 3, 5, b'0', '0.375', 171, '0000-00-00', -35, 22, '2-Jan', '3-Feb', '0-4', '0.000', '5-Feb', 'Jan-00', '2L', '3-Feb'),
(5, 'Cincinnati Bengals', 8, 0, b'0', '1.000', 229, '0000-00-00', 87, 28, 'Apr-00', 'Apr-00', 'Mar-00', '1.000', 'Jul-00', 'Jan-00', '8W', 'May-00'),
(6, 'Pittsburgh Steelers', 5, 4, b'0', '0.556', 206, '0000-00-00', 24, 22, '2-Mar', '2-Feb', '0-2', '0.000', '4-Feb', 'Mar-00', '1W', '2-Mar'),
(7, 'Baltimore Ravens', 2, 6, b'0', '0.250', 190, '0000-00-00', -24, 19, '2-Jan', '4-Jan', '2-Jan', '0.333', '4-Feb', '0-2', '1W', '3-Feb'),
(8, 'Cleveland Browns', 2, 7, b'0', '0.222', 177, '0000-00-00', -70, 19, '3-Jan', '4-Jan', '1-Jan', '0.500', '5-Feb', '0-2', '4L', '4-Jan'),
(9, 'Indianapolis Colts', 4, 5, b'0', '0.444', 200, '0000-00-00', -27, 24, '3-Feb', '2-Feb', 'Mar-00', '1.000', '3-Apr', '0-2', '1W', '3-Feb'),
(10, 'Houston Texans', 3, 5, b'0', '0.375', 174, '0000-00-00', -31, 21, '2-Feb', '3-Jan', '1-Feb', '0.667', '3-Feb', '2-Jan', '1W', '3-Feb'),
(11, 'Jacksonville Jaguars', 2, 6, b'0', '0.250', 170, '0000-00-00', -65, 20, '2-Feb', '0-4', '0-2', '0.000', '4-Feb', '0-2', '1L', '4-Jan'),
(12, 'Tennessee Titans', 2, 6, b'0', '0.250', 159, '0000-00-00', -28, 19, '0-4', '2-Feb', '0-2', '0.000', '0-5', '1-Feb', '1W', '4-Jan'),
(13, 'Denver Broncos', 7, 1, b'0', '0.875', 192, '0000-00-00', 53, 19, 'Mar-00', '1-Apr', 'Feb-00', '1.000', '1-Apr', 'Mar-00', '1L', '1-Apr'),
(14, 'Oakland Raiders', 4, 4, b'0', '0.500', 213, '0000-00-00', 2, 25, '2-Feb', '2-Feb', '1-Jan', '0.500', '3-Apr', '0-1', '1L', '3-Feb'),
(15, 'Kansas City Chiefs', 3, 5, b'0', '0.375', 195, '0000-00-00', 13, 21, '2-Feb', '3-Jan', '0-1', '0.000', '2-Feb', '3-Jan', '2W', '3-Feb'),
(16, 'San Diego Chargers', 2, 7, b'0', '0.222', 210, '0000-00-00', -39, 23, '3-Feb', '0-4', '0-1', '0.000', '4-Jan', '3-Jan', '5L', '0-5'),
(17, 'New York Giants', 5, 4, b'0', '0.556', 247, '0000-00-00', 21, 27, '1-Mar', '3-Feb', '2-Feb', '0.500', '4-Apr', 'Jan-00', '1W', '2-Mar'),
(18, 'Philadelphia Eagles', 4, 4, b'0', '0.500', 193, '0000-00-00', 29, 22, '1-Feb', '3-Feb', '2-Feb', '0.500', '4-Mar', 'Jan-00', '1W', '2-Mar'),
(19, 'Washington Redskins', 3, 5, b'0', '0.375', 158, '0000-00-00', -37, 17, '1-Mar', '0-4', '1-Jan', '0.500', '2-Mar', '0-3', '1L', '3-Feb'),
(20, 'Dallas Cowboys', 2, 6, b'0', '0.250', 160, '0000-00-00', -44, 16, '4-Jan', '2-Jan', '2-Feb', '0.500', '5-Feb', '0-1', '6L', '0-5'),
(21, 'Green Bay Packers', 6, 2, b'0', '0.750', 203, '0000-00-00', 36, 24, 'Apr-00', '2-Feb', 'Jan-00', '1.000', '1-Apr', '1-Feb', '2L', '2-Mar'),
(22, 'Minnesota Vikings', 6, 2, b'0', '0.750', 168, '0000-00-00', 28, 16, 'Apr-00', '2-Feb', 'Mar-00', '1.000', '1-Apr', '1-Feb', '4W', '1-Apr'),
(23, 'Chicago Bears', 3, 5, b'0', '0.375', 162, '0000-00-00', -59, 16, '3-Jan', '2-Feb', '0-3', '0.000', '0-5', 'Mar-00', '1W', '2-Mar'),
(24, 'Detroit Lions', 1, 7, b'0', '0.125', 149, '0000-00-00', -96, 18, '3-Jan', '0-4', '2-Jan', '0.333', '4-Jan', '0-3', '2L', '4-Jan'),
(25, 'Carolina Panthers', 8, 0, b'0', '1.000', 228, '0000-00-00', 63, 26, 'May-00', 'Mar-00', 'Feb-00', '1.000', 'May-00', 'Mar-00', '8W', 'May-00'),
(26, 'Atlanta Falcons', 6, 3, b'0', '0.667', 229, '0000-00-00', 39, 27, '1-Mar', '2-Mar', '0-2', '0.000', '3-Apr', 'Feb-00', '2L', '3-Feb'),
(27, 'New Orleans Saints', 4, 5, b'0', '0.444', 241, '0000-00-00', -27, 31, '2-Mar', '3-Jan', '2-Jan', '0.333', '4-Mar', '1-Jan', '1L', '2-Mar'),
(28, 'Tampa Bay Buccaneers', 3, 5, b'0', '0.375', 181, '0000-00-00', -50, 18, '3-Jan', '2-Feb', '1-Feb', '0.667', '3-Feb', '2-Jan', '1L', '3-Feb'),
(29, 'Arizona Cardinals', 6, 2, b'0', '0.750', 263, '0000-00-00', 110, 32, '1-Mar', '1-Mar', '1-Jan', '0.500', '1-Apr', '1-Feb', '2W', '2-Mar'),
(30, 'St. Louis Rams', 4, 4, b'0', '0.500', 153, '0000-00-00', 7, 16, '1-Mar', '3-Jan', 'Mar-00', '1.000', '3-Mar', '1-Jan', '1L', '2-Mar'),
(31, 'Seattle Seahawks', 4, 4, b'0', '0.500', 167, '0000-00-00', 27, 16, '1-Feb', '3-Feb', '1-Jan', '0.500', '3-Apr', '0-1', '2W', '2-Mar'),
(32, 'San Francisco 49ers', 3, 6, b'0', '0.333', 126, '0000-00-00', -97, 12, '2-Mar', '0-4', '0-3', '0.000', '5-Feb', '1-Jan', '1W', '3-Feb');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ci_sessions`
--
ALTER TABLE `ci_sessions`
  ADD PRIMARY KEY (`session_id`),
  ADD KEY `last_activity_idx` (`last_activity`);

--
-- Indexes for table `roster`
--
ALTER TABLE `roster`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `standing`
--
ALTER TABLE `standing`
  ADD PRIMARY KEY (`Id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
